interface Sayable {
    void say();
}

public class lamda {
    public static void main(String[] args) {
        Sayable s = () -> System.out.println("Hello with lambda!");
        s.say();
    }
}
