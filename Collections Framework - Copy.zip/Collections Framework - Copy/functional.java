@FunctionalInterface   //tells its functional interface use only one abstract unimplemented methodd and also use lambda
interface Calculator {
    int add(int a, int b);
}

public class functional {
    public static void main(String[] args) {
        Calculator c = (a, b) -> a + b; // lambda
        System.out.println("Sum: " + c.add(5, 3));
    }
}

