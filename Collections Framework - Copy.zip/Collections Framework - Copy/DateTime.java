import java.time.*;

public class DateTime {
    public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        LocalTime time = LocalTime.now();
        LocalDateTime dateTime = LocalDateTime.now();

        System.out.println("Date: " + today);
        System.out.println("Time: " + time);
        System.out.println("Date & Time: " + dateTime);
    }
}

