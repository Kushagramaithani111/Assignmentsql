import java.util.*;

public class methodreference {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Devansh", "Amit", "Riya");

        names.forEach(System.out::println);
    }
}
